
import React from "react";
import { useState, useEffect } from "react";
import Axios from "axios";


import "./style.css";

export default function App(){

    const [name, setName] = useState("");
    const [surname, setsurname] = useState("");
    const [idNumber, setId] = useState(0);
    const [email, setEmail] = useState("");
    const [gender, setGender] = useState("");
    const [age, setAge] = useState(0);

    const [listOfPersonalData, setListOfPersonalData] = useState([]);

    const addPersonalData = () => {
     
     Axios.post('http://localhost:5000/addPersonalData',
    {name: name, surname: surname, idNumber: idNumber, email: email, gender: gender, age: age,
    }).then(()=> {
        setListOfPersonalData([...listOfPersonalData, {name: name, surname: surname, idNumber: idNumber, email: email, gender: gender, age: age}]);
    })
};

const updatePersonalData = (id) => {
  const newAge = prompt("Enter new age:")
  Axios.put('http://localhost:5000/update', {newAge: newAge, id: id});
}

useEffect(() => {
    Axios.get('http://localhost:5000/read',
    {name: name, surname: surname, idNumber: idNumber, email: email, gender: gender, age: age})
    .then((response) => {
      setListOfPersonalData(response.data);
      const update = prompt("Enter val");
      console.log(update);
    }).catch(() => {
        console.log('ERROR');
    });
}, []);


    return (
    <div classname="App">
        <div id="inputs">
            <input type="text" placeholder="Name:" onChange={(event) => {setName(event.target.value);}} />
            <input type="text" placeholder="Surname:" onChange={(event) => {setsurname(event.target.value);}} />
            <input type="number" placeholder="S.A ID:" onChange={(event) => {setId(event.target.value);}} />
            <input type="text" placeholder="Email:" onChange={(event) => {setEmail(event.target.value);}} />
            <input type="text" placeholder="Gender:" onChange={(event) => {setGender(event.target.value);}} />
            <input type="number" placeholder="Age:" onChange={(event) => {setAge(event.target.value);}} />
            <button onClick={addPersonalData}>ADD INFORMATION</button>
        </div>

        <div id="ListOfPersonalData">
        {listOfPersonalData.map((val) => {
            return (
             <div id="personalContainer">   
            <div id="personal">
           <h3>Name: {val.name} </h3>
           <h3>Surname: {val.surname} </h3>
           <h3>S.A ID: {val.idNumber} </h3>
           <h3>Email: {val.email} </h3>
           <h3>Gender: {val.gender} </h3>
           <h3>Age: {val.age} </h3>
        </div>
        <button onClick={() => {
            updatePersonalData(val._id);
            }}
            >
            Update
        </button>
        <button>Delete</button>
        </div>
        );
        })}
        </div>
     </div> 
     
   );
   
}
 



