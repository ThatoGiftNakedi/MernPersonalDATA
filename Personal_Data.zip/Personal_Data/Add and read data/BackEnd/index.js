const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const personalDataModel = require("./models/personalData");
require("dotenv").config();
const app = express();


app.use(cors());
app.use(express.json());


//This is the database connection
//MONGODB_CONNECTION_STRING= "mongodb+srv://thatoisadmin:kamogelo94@cluster0.gta0j.mongodb.net/<dbname>?retryWrites=true&w=majority"
mongoose.connect("mongodb+srv://thatoisadmin::kamogelo94@cluster0.gta0j.mongodb.net/<dbname>?retryWrites=true&w=majority", {
    useNewUrlParser: true, 
    useUnifiedTopology: true,
    useCreateIndex: true
}, (err)=> {
    if(err) throw err;
    console.log("MongoDB has connected successfully");
});


app.post("/addPersonalData", async (req, res) => {
    const name = req.body.name;
    const surname = req.body.surname;
    const email = req.body.email;
    const idNumber = req.body.idNumber;
    const gender = req.body.gender;
    const age = req.body.age;

    const personalD = new personalDataModel({ name: name, surname: surname, idNumber: idNumber , email: email, gender: gender, age: age});
    await personalD.save();
    res.send("Success");
    
});

app.get("/read", async (req, res) => {
    personalDataModel.find({}, (err, result) =>{
        if (err){
            res.send(err);
        }else{
        res.send(result);
    }
});
});

app.put("/update",  async (req, res) => {
    const newAge = req.body.newAge;
    const id = req.body.id;
    console.log(newAge, id);

    try {
        await personalDataModel.findById(id, (error, personalDataToUpdate) => {
            personalDataToUpdate.age = Number(newAge);
            personalDataToUpdate.save();
        });

    }catch(err) {
        console.log(err);
    }
    res.send('Updated');
});
    
const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log(`The server is running on port: ${PORT}`));


//connect to a mongoDB database

