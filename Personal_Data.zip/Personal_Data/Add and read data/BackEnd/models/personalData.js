const mongoose =  require("mongoose");

const personalDataSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },

    surname: {
        type: String,
        required: true
    },

    idNumber: {
        type: Number,
        required: true
    },

    email: {
        type: String,
        required: true
    },

    gender: {
        type: String,
        required: true
    },

    age: {
        type: Number,
        required: true
    },
});

const personalDataModel = mongoose.model('personaldatas', personalDataSchema)
module.exports = personalDataModel;